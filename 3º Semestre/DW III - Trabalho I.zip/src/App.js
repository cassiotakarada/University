import React from "react";

import Main from "./Pages/Main"; 

function App() {
   return (
    <>
      <Main />
    </>
  );
}

export default App;
